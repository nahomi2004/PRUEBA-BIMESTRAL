/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

import Entidades.DireccEntrega;

/**
 *
 * @author andreflores
 */
public class LDirecc {

    private DireccEntrega pDirecc;

    public LDirecc(DireccEntrega pDirecc) {
        this.pDirecc = pDirecc;
    }

    public Boolean comprobarCalles (){
        String principal = pDirecc.getCalle1().replaceAll("\\D", "").toLowerCase();
        String sec1 = pDirecc.getCalle2().replaceAll("\\D", "").toLowerCase();

        return principal.equals(sec1);
    }
}