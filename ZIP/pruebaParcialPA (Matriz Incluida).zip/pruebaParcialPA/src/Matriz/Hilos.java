package Matriz;

import java.util.Scanner;

public class Hilos extends Thread {
    private static int[][] matriz;
    private static int cont = 0;
    private static int cont2 = 0;
    private int f;
    private int c;
    private int n;

    public Hilos(int f, int c, int n) {
        this.f = f;
        this.c = c;
        this.n = n;
        matriz = new int[f][c];
    }

    @Override
    public void run() {
        for(int i = 0; i < c; i++) {
            System.out.println(getName() + " Agregado: " + n);
            matriz[cont2][cont] = n;
            cont++;
            cont2++;
            if (cont2 == f) {
                cont2 = 0;
            }
            if (cont == c) {
                cont = 0;
            }
        }
    }

    public static int[][] getMatriz() {
        return matriz;
    }

    public static void main(String[] args) {
        Hilos h1 = new Hilos(3,4,1);
        Hilos h2 = new Hilos(3,4,2);
        Hilos h3 = new Hilos(3,4,3);
        // Hilos h4 = new Hilos(3,4,1);

        h1.start();
        h2.start();
        h3.start();

        try {
            h1.join();
            h2.join();
            h3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print(getMatriz()[i][j]);
            }
            System.out.println();
        }
    }
}
