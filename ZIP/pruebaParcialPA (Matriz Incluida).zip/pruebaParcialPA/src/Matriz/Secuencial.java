package Matriz;

import java.util.Random;
import java.util.Scanner;

// Llenar una matriz de dimensión (n x m (par)) con valores de 1 a n de forma aleatoria en la proporcion de veces cada
// numero (si la matriz es 3x4 se debe llenar con 1,2,3 4 veces cada numero de forma aleatoria)
public class Secuencial {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random r = new Random();

        System.out.println("Ingrese las filas:");
        int f = sc.nextInt();
        System.out.println("Ingrese las columnas (número par):");
        int c = sc.nextInt();

        int [][] matriz = new int[f][c];

        if (c % 2 != 0) {
            System.out.println("Las columnas deben ser un número par");
        } else {

            for (int i = 0; i < f; i++) {
                for (int j = 0; j < c; j++) {
                    int n = 1 + r.nextInt(f);
                    matriz[i][j] = n;
                }
            }
        }

        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                System.out.print(matriz[i][j]);
            }
            System.out.println();
        }
    }
}
