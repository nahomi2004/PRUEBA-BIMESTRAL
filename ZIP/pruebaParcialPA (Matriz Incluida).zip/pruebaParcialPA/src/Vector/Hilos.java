package Vector;

public class Hilos extends Thread {

    private int n;
    private static int vector[] = new int [80];
    private static int cont = 0;
    private int rango = 20;

    public Hilos(int n) {
        this.n = n;
    }

    @Override
    public void run() {
        for(int i = 0; i < rango; i++) {
            System.out.println("Agregado: " + n);
            vector[cont] = n;
            cont++;
        }
    }

    public int getN() {
        return n;
    }

    public static int[] getVector() {
        return vector;
    }

    public static void main(String[] args) {
        Hilos h1 = new Hilos(1);

        Hilos h2 = new Hilos(2);

        Hilos h3 = new Hilos(3);

        Hilos h4 = new Hilos(4);

        h1.start();
        h2.start();
        h3.start();
        h4.start();

        try {
            h1.join();
            h2.join();
            h3.join();
            h4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        int uwu = 1;
        for(int xd: getVector()) {
            System.out.print(xd + " - ");
            if(uwu == 20 || uwu == 40 || uwu == 60) {
                System.out.println();
            }
            uwu++;
        }
    }
}
