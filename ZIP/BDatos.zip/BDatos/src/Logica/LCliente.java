package Logica;

import Cliente.Cliente;
import Datos.BDCliente;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;

public class LCliente {
    static BDCliente cliente = new BDCliente();
    public LCliente() {
    }
    public void agregarCliente(Cliente clientewtf) throws SQLException, ClassNotFoundException {
        cliente.insertarCliente(clientewtf);
    }

    public Boolean comprobarCedula(String cedula) {
        return cedula.length() == 10 && cedula.substring(0, 9).matches("[0-9]*");
    }



    public Cliente ObtenerCliente(Cliente objCliente) throws ClassNotFoundException, SQLException {
        //TRABAJPO de los algoritmos
        ResultSet rs = cliente.RecuperarUsuarios1(objCliente);
        while (rs.next()){
            objCliente.setIdCliente(rs.getInt(1));
            objCliente.setNombres(rs.getString(2));
            objCliente.setApellidos(rs.getString(3));
            objCliente.setCdl(rs.getString(4));
        }
        rs.close();
        return objCliente;
    }
}
