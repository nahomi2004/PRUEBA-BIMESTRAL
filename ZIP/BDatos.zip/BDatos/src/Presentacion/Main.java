package Presentacion;

import Cliente.Cliente;
import Logica.LCliente;

import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    static Cliente cliente1 = new Cliente(0, "1150057501", "Nahomi", "Cabrera");
    static LCliente lCliente1 = new LCliente();
    static Scanner entrada = new Scanner(System.in);
    static Cliente cliente = new Cliente();

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        lCliente1.agregarCliente(cliente1);
        int menu = 0;

        System.out.println("BIENVENIDOS A TU NUEVO LUGAR FAVORITO");
        do {
            System.out.println("Ingresar Cliente [1]");
            System.out.println("Buscar [2]");
            System.out.println("Salir [0]");
            menu = entrada.nextInt();

            switch (menu) {
                case 1:
                    if (agregarClienteMain().isEmpty()) {
                        System.out.println("No se puede ingresar el cliente");
                    } else {
                        lCliente1.agregarCliente(agregarClienteMain());
                    }
                    break;
                case 2:
                    System.out.println("Ingrese el número de cdl:");
                    String cdl = entrada.next();
                    cliente.setCdl(cdl);
                    if (lCliente1.ObtenerCliente(cliente).isEmpty()) {
                        System.out.println("No existe ese cliente");
                    } else {
                        System.out.println(cliente);
                    }
                    break;
            }
        } while(menu != 0);
    }

    public static Cliente agregarClienteMain() {
        System.out.println("Ingrese el nombre:");
        String nombre = entrada.nextLine();

        System.out.println("Ingrese los apellidos:");
        String apellido = entrada.nextLine();

        System.out.println("Ingrese la cdl:");
        String cdl = entrada.nextLine();

        LCliente lCliente = new LCliente();

        if (lCliente.comprobarCedula(cdl)) {
            return new Cliente(0, nombre, apellido, cdl);
        } else {
            System.out.println("No se puede ingresar el cliente, revise la cdl");
        }
        return new Cliente();
    }
}