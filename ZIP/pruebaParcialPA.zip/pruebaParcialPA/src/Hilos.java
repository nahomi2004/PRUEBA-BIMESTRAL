import java.util.Random;
import java.util.random.RandomGenerator;

public class Hilos extends Thread {

    String [] vector = new String[20];

    @Override
    public void run() {
        String [] abcd = new String [4];
        abcd[0] = "a";
        abcd[1] = "b";
        abcd[2] = "c";
        abcd[3] = "d";

        int uwu = 0;

        for(int i = 0; i < vector.length; i++) {
            vector[i] = abcd[uwu];
            if(i == 4 || i == 9 || i == 14 || i == 19) {
                uwu ++;
            }
        }
    }

    public String[] getVector() {
        return vector;
    }

    /*
    public String[] llenarVectorA() {
        String[] vectorA = new String[20];

        for(int i = 0; i < vectorA.length; i++) {
            vectorA[i] = "a";
        }

        return vectorA;
    }

    public String[] llenarVectorB() {
        String[] vectorA = new String[20];

        for(int i = 0; i < vectorA.length; i++) {
            vectorA[i] = "b";
        }

        return vectorA;
    }

    public String[] llenarVectorC() {
        String[] vectorA = new String[20];

        for(int i = 0; i < vectorA.length; i++) {
            vectorA[i] = "c";
        }

        return vectorA;
    }

    public String[] llenarVectorD() {
        String[] vectorA = new String[20];

        for(int i = 0; i < vectorA.length; i++) {
            vectorA[i] = "d";
            System.out.println("\t\t\th4");
        }

        return vectorA;
    }

     */

    public static void main(String[] args) {
        Hilos h1 = new Hilos();

        Hilos h2 = new Hilos();

        Hilos h3 = new Hilos();

        Hilos h4 = new Hilos();

        h1.start();
        h2.start();
        h3.start();
        h4.start();

        /*
        String[] v1 = h1.llenarVectorB();
        String[] v2 = h2.llenarVectorB();
        String[] v3 = h3.llenarVectorC();
        String[] v4 = h4.llenarVectorD();

         */

        try {
            h1.join();
            h2.join();
            h3.join();
            h4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String[] vector = new String[80];

        int uwu = 1;

        for(int i=0; i < vector.length; i++) {
            if (i <= 19) {
                vector[i] = h1.getVector()[i];
            } else if (i > 19 && i <= 39) {
                vector[i] = h2.getVector()[i-20];
            } else if (i > 39 && i <= 59) {
                vector[i] = h3.getVector()[i-40];
            } else if (i > 59 && i <= 79) {
                vector[i] = h4.getVector()[i-60];
            }
        }

        for(String v: vector) {
            System.out.println(v + " " + uwu);
            uwu++;
        }
    }
}
