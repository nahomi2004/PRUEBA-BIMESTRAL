// @Author: CABRERA PICOITA NAHOMI ASTRID

import java.util.Random;
import java.util.random.RandomGenerator;

import static java.lang.Math.random;

public class Secuencial {
    public static void main(String[] args) {

        String [] abcd = new String [4];
        abcd[0] = "a";
        abcd[1] = "b";
        abcd[2] = "c";
        abcd[3] = "d";

        String [] vector = new String[80];

        int uwu = 0;

        for(int i = 0; i < vector.length; i++) {
            vector[i] = abcd[uwu];
            if(i == 19 || i == 39 || i == 59 || i == 79) {
                uwu ++;
            }
        }

        for(String v: vector) {
            System.out.println(v);
        }
    }
}