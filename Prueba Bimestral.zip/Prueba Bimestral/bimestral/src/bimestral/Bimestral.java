
package bimestral;

import java.util.List;
import java.util.Map;
import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.metamodel.Metamodel;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class Bimestral {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("bimestral_PU");
        EntityManager em = emf.createEntityManager();
        
        List<Valores> numeros = em.createQuery("SELECT v FROM valores v", Valores.class).getResultList();
    }
    
    public static void hacertodo(List<Valores> numeros) {
        System.out.println(numeros.size());
        
        // var numCores = Runtime.getRuntime().availableProcessors();
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(5);
        CountDownLatch endController = new CountDownLatch(5);
        int [] v1 = new int[400];
        int [] v2 = new int[400];
        int [] v3 = new int[400];
        int [] v4 = new int[400];
        int [] v5 = new int[400];
        for (int i = 0; i < numeros.size(); i++) {
            if (i < 400) {
                v1[i] = Integer.valueOf(numeros.get(i).toString());
                //
            } else if (i >= 400 && i < 800) {
                v2[i-400] = Integer.valueOf(numeros.get(i).toString());
            } else if (i >= 800 && i < 1200) {
                v3[i-800] = Integer.valueOf(numeros.get(i).toString());
            } else if (i >= 1200 && i < 1600) {
                v3[i-1200] = Integer.valueOf(numeros.get(i).toString());
            } else if (i >= 1600 && i < 2000) {
                v3[i-1600] = Integer.valueOf(numeros.get(i).toString());
            }
        }
        
        Hilo h1 = new Hilo(v1, endController);
        Thread t = new Thread(h1);
        executor.execute(t);
        Thread t2 = new Thread(new Hilo(v2, endController));
        executor.execute(t2);
        Thread t3 = new Thread(new Hilo(v3, endController));
        executor.execute(t3);
        Thread t4 = new Thread(new Hilo(v4, endController));
        executor.execute(t4);
        Thread t5 = new Thread(new Hilo(v5, endController));
        executor.execute(t5);
        
        try {
            endController.await();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        
        executor.shutdown();
        System.out.println("\n\n\n");
        
        System.out.println("Total de números primos: " + h1.getContNumPrimos());
    }
}
