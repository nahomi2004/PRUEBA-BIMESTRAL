/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bimestral;
import java.util.ArrayList;
import javax.persistence.*;
/**
 *
 * @author D E L L
 */
@Entity
@Table(name = "valores")
public class Valores {
    @Id
    private int id;
    
    private int col1;
    private int col2;
    private int col3;
    private int col4;
}
