package org.example;

import Entidades.Herencia.Cliente;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.Scanner;

public class Main {
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("BIENVENIDOS A TU MENÚ, ELIGE LA OPCIÓN QUE CONSIDERES CORRECTA");
        int menu = sc.nextInt();

        do {
            System.out.println("Seleccione el rol:");
            System.out.println("Cliente             [1]");
            System.out.println("Empleado            [2]");
            System.out.println("Salir               [0]");
            int op = sc.nextInt();

            switch (op) {
                case 1:
                    System.out.println("Muy buenas, ¿cómo está? ¿Qué desea hacer como cliente?");
                    System.out.println("Revisar el estado de su paquete     [1]");
                    System.out.println("Agregar su dirección actual         [2]");
                    System.out.println("Salir                               [0]");
                    int uwu = sc.nextInt();
                    switch (uwu) {
                        case 1:
                            break;

                        case 2:
                            break;

                    }
                    break;

                case 2:
                    System.out.println("Por favor, elija el tipo de empleado que es:");
                    System.out.println("Repartidor      [1]");
                    System.out.println("Bodeguero       [2]");
                    System.out.println("Salir           [0]");
                    int uwu1 = sc.nextInt();
                    switch (uwu1) {
                        case 1:
                            System.out.println("Registrar la entrega de un paquete      [1]");
                            System.out.println("Salir                                   [0]");
                            int uwuR = sc.nextInt();
                            switch (uwuR) {
                                case 1:
                                    break;

                                case 2:
                                    break;

                            }
                            break;
                        case 2:
                            System.out.println("Registrar un nuevo cliente                                      [1]");
                            System.out.println("Agregar al cliente sus direcciones (el cliente ya debe existir) [2]");
                            System.out.println("Registrar un nuevo paquete                                      [3]");
                            System.out.println("Editar el estado de un paquete                                  [4]");
                            System.out.println("Salir                                                           [0]");
                            int uwuB = sc.nextInt();
                            switch (uwuB) {
                                case 1:
                                    break;

                                case 2:
                                    break;

                                case 3:
                                    break;

                                case 4:
                                    break;

                            }
                            break;
                    }
                    break;
            }

        } while(menu != 0);


        try (EntityManagerFactory entityManagerFactory =
                     Persistence.createEntityManagerFactory("persistenciaUWU")) {
            /* EntityManager -> Persistence Context*/
            EntityManager em = entityManagerFactory.createEntityManager(); // Representa el conexto de persistencia, se utiliza para manejar las transacciones

            em.getTransaction().begin();

            Cliente c = new Cliente("1150057501","Nahomi","Cabrera","na@utpl.ec", "+593 968467693");
            em.persist(c);

            System.out.println(c);

            em.getTransaction().commit();
        }
    }


    // System.out.println("Revisar el estado de su paquete     [1]");
    public static void revisarEstadoPaquete() {
        System.out.println("Ingrese su cédula: ");
        String cdl = sc.nextLine();


    }
}