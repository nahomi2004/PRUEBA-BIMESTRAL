package org.example;

import BDProyecto.Controller;
import BDProyecto.PersonaJpaController;
import Entidades.Herencia.*;
import Entidades.NoHerencia.*;
import Logica.LPersona;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
// import jakarta.persistence.EntityManagerFactory;
// import jakarta.persistence.Persistence;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner sc = new Scanner(System.in);
    private static final Controller controller = new Controller();
    private static int numCU = 0;
    private static int numEn = 0;

    public static void main(String[] args) {
        int op;
        System.out.println("BIENVENIDOS A TU MENÚ, ELIGE LA OPCIÓN QUE CONSIDERES CORRECTA");

        do {
            System.out.println("Seleccione el rol:");
            System.out.println("Cliente             [1]");
            System.out.println("Empleado            [2]");
            System.out.println("Salir               [0]");
            op = sc.nextInt();
            sc.nextLine(); // Limpiar el buffer de entrada

            switch (op) {
                case 0:
                    System.out.println("Espero habele ayudado. Hasta pronto :3");
                    break;
                case 1:
                    System.out.println("Muy buenas, ¿cómo está? ¿Qué desea hacer como cliente?");
                    System.out.println("Revisar el estado de su paquete     [1]");
                    System.out.println("Agregar su dirección actual         [2]");
                    System.out.println("Salir                               [0]");
                    int uwu = sc.nextInt();
                    sc.nextLine(); // Limpiar el buffer de entrada
                    switch (uwu) {
                        case 0:
                            System.out.println("Espero habele ayudado. Hasta pronto :3");
                            break;
                        case 1:
                            revisarEstadoPaquete();
                            break;
                        case 2:
                            agregarUbiActual();
                            break;
                        default:
                            System.err.println("Número no válido");
                            break;
                    }
                    break;

                case 2:
                    System.out.println("Por favor, elija el tipo de empleado que es:");
                    System.out.println("Repartidor      [1]");
                    System.out.println("Bodeguero       [2]");
                    System.out.println("Salir           [0]");
                    int uwu1 = sc.nextInt();
                    sc.nextLine(); // Limpiar el buffer de entrada
                    switch (uwu1) {
                        case 0:
                            System.out.println("Espero habele ayudado. Hasta pronto :3");
                            break;
                        case 1:
                            System.out.println("Registrar la entrega de un paquete      [1]");
                            System.out.println("Registrar Repartidor                    [2]");
                            System.out.println("Salir                                   [0]");
                            int uwuR = sc.nextInt();
                            sc.nextLine(); // Limpiar el buffer de entrada
                            switch (uwuR) {
                                case 0:
                                    System.out.println("Espero habele ayudado. Hasta pronto :3");
                                    break;
                                case 1:
                                    registrarEntregaPaquete();
                                    break;
                                case 2:
                                    registrarNuevoRepartidor();
                                    break;
                                default:
                                    System.err.println("Número no válido");
                                    break;
                            }
                            break;
                        case 2:
                            System.out.println("Registrar un nuevo cliente                                      [1]");
                            System.out.println("Agregar al cliente sus direcciones (el cliente ya debe existir) [2]");
                            System.out.println("Registrar un nuevo paquete                                      [3]");
                            System.out.println("Editar el estado de un paquete                                  [4]");
                            System.out.println("Registrar Bodeguero                                             [5]");
                            System.out.println("Salir                                                           [0]");
                            int uwuB = sc.nextInt();
                            sc.nextLine(); // Limpiar el buffer de entrada
                            switch (uwuB) {
                                case 0:
                                    System.out.println("Espero habele ayudado. Hasta pronto :3");
                                    break;
                                case 1:
                                    registrarNuevoCliente();
                                    break;
                                case 2:
                                    agregarUbicacionCliente();
                                    break;
                                case 3:
                                    registrarNuevoPaquete();
                                    break;
                                case 4:
                                    editarEstadoPaquete();
                                    break;
                                case 5:
                                    registrarNuevoBodeguero();
                                    break;
                                default:
                                    System.err.println("Número no válido");
                                    break;
                            }
                            break;

                        default:
                            System.err.println("Número no válido");
                            break;
                    }
                    break;
                default:
                    System.err.println("Número no válido");
                    break;
            }

        } while (op != 0);
    }

    // AQUÍ ACABA EL MAIN
    // Y EMPIEZAN LOS MÉTODOS
    public static Boolean existeEstaPersona(String id) {
        if(controller.buscarPersona(id) != null) {
            return true;
        }
        return false;
    }

    public static void registrarNuevoCliente() {
        LPersona lcliente = new LPersona();
        EntityManager em = controller.getEntityManager();
        sc.nextLine(); // limpiar el buffer o algo así
        System.out.print("Cédula: ");
        String cedula = sc.nextLine();


        // Validar si existe esta cdl
        while (existeEstaPersona(cedula)) {
            sc.nextLine();
            System.out.println("Esta persona ya existe, por favor ingrese otro número de cédula:");
            cedula = sc.nextLine();
        }

        // Validar la cédula
        while (!lcliente.comprobarCedula(cedula)) {
            System.out.println("Cédula inválida. Por favor, ingrese una cédula válida de 10 dígitos.");
            System.out.print("Cédula: ");
            cedula = sc.nextLine();
        }

        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Apellido: ");
        String apellido = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();
        while (!lcliente.comprobarCorreo(email)) {
            System.out.println("Correo electronico invalido. Por favor, ingrese un correo electrónico valido.");
            System.out.print("Email: ");
            email = sc.nextLine();
        }

        System.out.print("Celular: ");
        String celular = sc.nextLine();

        Cliente cliente = new Cliente(cedula, nombre, apellido, email, celular);
        em.getTransaction().begin();
        em.persist(cliente);
        em.getTransaction().commit();

        System.out.println("Cliente registrado con éxito: " + cliente);
    }


    public static void registrarNuevoBodeguero() {
        LPersona lcliente = new LPersona();
        EntityManager em = controller.getEntityManager();
        sc.nextLine();

        System.out.print("Cédula: ");
        String cedula = sc.nextLine();

        // Validar si existe esta cdl
        while (existeEstaPersona(cedula)) {
            sc.nextLine();
            System.out.println("Esta persona ya existe, por favor ingrese otro número de cédula:");
            cedula = sc.nextLine();
        }

        // Validar la cédula
        while (!lcliente.comprobarCedula(cedula)) {
            System.out.println("Cédula inválida. Por favor, ingrese una cédula válida de 10 dígitos.");
            System.out.print("Cédula: ");
            cedula = sc.nextLine();
        }

        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Apellido: ");
        String apellido = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();
        while (!lcliente.comprobarCorreo(email)) {
            System.out.println("Correo electrónico inválido. Por favor, ingrese un correo electrónico válido.");
            System.out.print("Email: ");
            email = sc.nextLine();
        }

        System.out.print("Ciudad: ");
        String ciudad = sc.nextLine();

        System.out.print("Local: ");
        String local = sc.nextLine();

        Bodeguero bodeguero = new Bodeguero(cedula, nombre, apellido, email, ciudad, local);
        em.getTransaction().begin();
        em.persist(bodeguero);
        em.getTransaction().commit();

        System.out.println("Bodeguero registrado con éxito: " + bodeguero);
    }

    public static void registrarNuevoRepartidor() {
        LPersona lcliente = new LPersona();
        EntityManager em = controller.getEntityManager();
        sc.nextLine();

        System.out.print("Cédula: ");
        String cedula = sc.nextLine();

        // Validar si existe esta cdl
        while (existeEstaPersona(cedula)) {
            sc.nextLine();
            System.out.println("Esta persona ya existe, por favor ingrese otro número de cédula:");
            cedula = sc.nextLine();
        }

        // Validar la cédula
        while (!lcliente.comprobarCedula(cedula)) {
            System.out.println("Cédula inválida. Por favor, ingrese una cédula válida de 10 dígitos.");
            System.out.print("Cédula: ");
            cedula = sc.nextLine();
        }

        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Apellido: ");
        String apellido = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();
        while (!lcliente.comprobarCorreo(email)) {
            System.out.println("Correo electrónico inválido. Por favor, ingrese un correo electrónico válido.");
            System.out.print("Email: ");
            email = sc.nextLine();
        }

        System.out.print("Ciudad: ");
        String ciudad = sc.nextLine();

        System.out.print("Zona: ");
        int zona = sc.nextInt();
        sc.nextLine();

        Repartidor repartidor = new Repartidor(cedula, nombre, apellido, email, ciudad, zona);
        em.getTransaction().begin();
        em.persist(repartidor);
        em.getTransaction().commit();

        System.out.println("Repartidor registrado con éxito: " + repartidor);
    }

    public static Boolean comprobarCodDirecc(String cod, List<Direccion> direccions) {
        if (cod.isEmpty()) { // puede que el usuario haya ingresado solo letras
            return true;
        }
        for (Direccion d : direccions) {
            String soloNumeros = d.getCodigo().replaceAll("[^\\d]", ""); // Reemplaza todo lo que no sea un número por ""
            if (soloNumeros.equals(cod)) {
                return true;
            }
        }
        return false;
    }

    public static void agregarUbiActual() {
        System.out.println("Ingrese la cédula del cliente:");
        String cdl = sc.nextLine();

        EntityManager em = controller.getEntityManager();

        try {
            // Comienza una nueva transacción
            em.getTransaction().begin();

            // Busca el cliente en la base de datos
            Cliente c = em.find(Cliente.class, cdl);

            if (c != null) {
                // Agregar direccion
                List<Direccion> direccions = c.getDirecciones();
                System.out.println("Código de casa (Solo números):");
                String cod = sc.next();
                sc.nextLine();
                System.out.println("Calle 1:");
                String c1 = sc.nextLine();
                System.out.println("Calle 2:");
                String c2 = sc.nextLine();
                System.out.println("Referencia:");
                String r = sc.next();

                String soloNumeros = cod.replaceAll("[^\\d]", ""); // Reemplaza todo lo que no sea un número por ""

                // Verificar que los datos ingresados no estén vacíos
                if (!c1.isEmpty() && !c2.isEmpty() && !r.isEmpty()) {
                    if (comprobarCodDirecc(soloNumeros, direccions)) {
                        System.out.println("No se puede agregar esta dirección");
                        System.err.println("Ya existe");
                    } else {
                        for (Direccion d : direccions) {
                            d.setActual(0);
                        }

                        c1 = c1.replaceAll("\\d", ""); // Reemplazo números por "" por si las dudas
                        c2 = c2.replaceAll("\\d", "");

                        String tresLetrasC1 = c1.substring(0, Math.min(c1.length(), 3)).replaceAll("\\s+", "");
                        String tresLetrasC2 = c2.substring(0, Math.min(c2.length(), 3)).replaceAll("\\s+", "");

                        cod = soloNumeros + "/" + tresLetrasC1 + "/" + tresLetrasC2;

                        Direccion d = new Direccion(cod, c1, c2, r, 1);
                        d.setCliente(c);

                        direccions.add(d);
                        c.setDirecciones(direccions);

                        controller.crearDireccion(d);
                        System.out.println("Dirección agregada exitosamente.");
                    }
                } else {
                    System.err.println("Los datos ingresados no son válidos.");
                }
            } else {
                System.err.println("Cliente no encontrado :(");
            }

            // Finaliza la transacción
            em.getTransaction().commit();
        } catch (Exception e) {
            // Si ocurre un error, revertir la transacción
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            // Asegurarse de cerrar el EntityManager
            if (em.isOpen()) {
                em.close();
            }
        }
    }

    public static void agregarUbicacionCliente() {
        int op = 0;
        do {
            System.out.println("Nueva dirección [1]");
            System.out.println("Salir           [0]");
            op = sc.nextInt();
            sc.nextLine();
            switch (op) {
                case 1:
                    System.out.println("Esta dirección agregada se entenderá como\n"
                            + "la dirección actual del cliente");
                    agregarUbiActual();
                    break;
                default:
                    System.err.println("Número no válido");
                    break;
            }
        } while (op != 0);
    }

    public static void revisarEstadoPaquete() {
        System.out.println("Ingrese su cédula");
        String cdl = sc.nextLine();

        EntityManager em = controller.getEntityManager();
        try {
            // Comienza una nueva transacción
            em.getTransaction().begin();

            // Busca el cliente en la base de datos
            Cliente c = em.find(Cliente.class, cdl);

            if (c != null) {
                // Forzamos la carga de los paquetes y sus estados
                List<Paquete> paquetes = c.getPaquetes();
                if (!paquetes.isEmpty()) {
                    for (Paquete p : paquetes) {
                        System.out.println("Paquete ID: " + p.getIdPaquete());
                        // Forzamos la carga de los estados
                        Estado[] estados = p.getEstados();
                        for (Estado es : estados) {
                            System.out.println("Estado: " + es.getTipo());
                            System.out.println("Fecha: " + es.getFecha());
                            System.out.println("Observación: " + es.getObservacion());
                        }
                    }
                } else {
                    System.err.println("No se han agregado paquetes a este cliente");
                }
            } else {
                System.err.println("Cliente no encontrado :(");
            }

            // Finaliza la transacción
            em.getTransaction().commit();
        } catch (Exception e) {
            // Si ocurre un error, revertir la transacción
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            // Asegurarse de cerrar el EntityManager
            if (em.isOpen()) {
                em.close();
            }
        }
    }

    public static void registrarEntregaPaquete() {
        System.out.println("Ingrese su cédula");
        String cdl = sc.nextLine();

        EntityManager em = controller.getEntityManager();
        try {
            // Comienza una nueva transacción
            em.getTransaction().begin();

            // Busca el repartidor en la base de datos
            Repartidor r = em.find(Repartidor.class, cdl);

            if (r != null) {
                LocalDate f = LocalDate.now();
                // Buscamos al cliente
                System.out.println("Ingresar la cédula del cliente al cuál se le hizo la entrega");
                String cdlCl = sc.next();
                Cliente c = em.find(Cliente.class, cdlCl);
                if (c != null) {
                    if (c.getPaquetes().size() > 1) {
                        for (Paquete p : c.getPaquetes()) {
                            System.out.println(p + "\n");
                        }
                        System.out.println("¿De qué paquete quiere registrar la entrega?");
                        String idP = sc.next();

                        // Ahora buscamos al paquete
                        Paquete p = em.find(Paquete.class, idP);
                        // Se valida que el paquete exista
                        if (p != null) {
                            // Creamos la entrega
                            System.out.println("Encontramos el paquete");
                            crearEntrega(f, r, p);
                        } else {
                            System.err.println("Error");
                            System.err.println("Ingresó mal el ID del paquete");
                        }
                        // Si se tiene solo un paquete entonces se trabaja sobre este
                    } else if (c.getPaquetes().size() == 1) {
                        Paquete p = em.find(Paquete.class, c.getPaquetes().get(0).getIdPaquete());
                        System.out.println("¡Enhorabuena!");
                        System.out.println("Este cliente solo ha tenido un paquete :D");
                        System.out.println("No va a haber mucho papeleo :D");
                        crearEntrega(f, r, p);
                        // Si no tiene ningún paquete entonces se muestra mensaje de error
                    } else {
                        System.err.println("ATENCIÓN:");
                        System.out.println("Este cliente no ha tenido ningún paquete registrado");
                    }
                } else {
                    System.err.println("Cliente no encontrado");
                }

            } else {
                System.err.println("Repartidor no encontrado :(");
            }

            // Finaliza la transacción
            em.getTransaction().commit();
        } catch (Exception e) {
            // Si ocurre un error, revertir la transacción
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            // Asegurarse de cerrar el EntityManager
            if (em.isOpen()) {
                em.close();
            }
        }
    }

    public static String crearCodEntrega(LocalDate f, String cdl) {
        String fecha = String.valueOf(f).replaceAll("\\s+", "");

        String cod = String.valueOf(numEn) + "//" + fecha + cdl.replace("\\s+", "");
        numEn++;
        return cod;
    }

    public static void crearEntrega(LocalDate f, Repartidor r, Paquete p) {
        System.out.println("Ingrese por favor los siguiente datos para registrar la entrega");
        System.out.println("Fecha de la entrega: " + f);

        String obs = "";

        do {
            System.out.println("Observación (sea breve por favor): ");
            obs = sc.next();
        } while (obs.length() > 255);

        String cod = crearCodEntrega(f, r.getCedula());
        Entrega e = new Entrega(cod, f, obs);
        e.setRepartidor(r);

        p.setEntrega(e);
        controller.crearEntrega(e);
    }

    public static int obtenerUltimoIdEstado() {
        EntityManager em = controller.getEntityManager();
        try {
            // Ejecutar la consulta JPQL para obtener el ID del último estado
            TypedQuery<Integer> query = em.createQuery("SELECT e.id FROM Estado e ORDER BY e.id DESC", Integer.class);
            query.setMaxResults(1); // Limitar los resultados a uno
            Integer ultimoId = query.getSingleResult(); // Obtener el único resultado
            return ultimoId != null ? ultimoId : 0; // Devolver el ID si se encontró, de lo contrario, devolver 0
        } finally {
            if (em.isOpen()) {
                em.close();
            }
        }
    }

    public static int obtenerUltimoIdPaquete() {
        EntityManager em = controller.getEntityManager();
        try {
            // Ejecutar la consulta JPQL para obtener el ID del último paquete
            TypedQuery<Integer> query = em.createQuery("SELECT MAX(e.id) FROM Paquete e", Integer.class);
            Integer ultimoId = query.getSingleResult(); // Obtener el resultado
            return ultimoId != null ? ultimoId : 0; // Devolver el ID si se encontró, de lo contrario, devolver 0
        } finally {
            if (em.isOpen()) {
                em.close();
            }
        }
    }

    public static void registrarNuevoPaquete() {
        sc.nextLine();
        System.out.println("Ingrese su cédula");
        String cdl = sc.nextLine();

        EntityManager em = controller.getEntityManager();
        try {
            // Comienza una nueva transacción
            em.getTransaction().begin();

            // Busca el repartidor en la base de datos
            Bodeguero b = em.find(Bodeguero.class, cdl);

            // sc.nextLine();
            if (b != null) {
                LocalDate f = LocalDate.now();
                // Buscamos al cliente
                System.out.println("Ingrese el número de cédula del cliente\n"
                        + "al cual desea agregarle el paquete");
                String cdlCl = sc.next();
                Cliente c = em.find(Cliente.class, cdlCl);

                if (c != null) {
                    System.out.println("Ingrese la descripción del paquete:");
                    String descrip = sc.next();
                    sc.nextLine();
                    System.out.println("Ingrese el peso:");
                    double peso = sc.nextDouble();
                    System.out.println("Ingrese el alto:");
                    double alto = sc.nextDouble();

                    String cod = generarCodPaquete(peso, alto, c);

                    Paquete p = new Paquete(obtenerUltimoIdPaquete() + 1, cod, descrip, peso, alto);
                    p.setBodeguero(b);
                    p.setCliente(c);
                    controller.crearPaquete(p);

                    Estado estado = new Estado(obtenerUltimoIdEstado() + 1, "Creado", LocalDate.now(), "Creado con éxito");
                    estado.setPaquete(p);
                    controller.crearEstado(estado);
                    // controller.actualizarEstado(estado);
                    p.getEstados()[0] = estado;
                    // Estado e = controller.buscarEstado(estado.getTipo());
                    // e.setPaquete(p);
                    // controller.actualizarEstado(e);
                    // p.getEstados()[0] = e;


                    c.getPaquetes().add(p);
                    controller.actualizarCliente(c);

                    controller.actualizarPaquete(p);
                    System.out.println("Paquete creado con éxito: \n" + p);
                } else {
                    System.err.println("Cliente no encontrado");
                }

                em.getTransaction().commit();
            } else {
                System.err.println("Bodeguero no encontrado :(");
            }

            // Finaliza la transacción
            // em.getTransaction().commit();
        } catch (Exception e) {
            // Si ocurre un error, revertir la transacción
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            // Asegurarse de cerrar el EntityManager
            if (em.isOpen()) {
                em.close();
            }
        }
    }

    public static String generarCodPaquete(double peso, double alto, Cliente c) {
        String cod = String.valueOf(peso) + "/" + String.valueOf(alto) + "/" + c.getCedula();
        return cod;
    }

    public static Estado actualizarSoloObs(Estado e) {
        System.out.println("Observación: ");
        String obs = sc.nextLine();
        e.setObservacion(obs);
        return e;
    }

    public static Estado crearEstadoPaquete(Paquete p, int index) {
        System.out.println("Observación: ");
        String obs = sc.nextLine();
        Estado e = new Estado(0, "Entregado", LocalDate.now(), obs);
        e.setPaquete(p);
        p.getEstados()[index] = e;
        return e;
    }

    public static void editarEstadoPaquete() {
        System.out.println("Ingrese su cédula");
        String cdl = sc.nextLine();

        EntityManager em = controller.getEntityManager();
        try {
            // Comienza una nueva transacción
            em.getTransaction().begin();

            // Busca el repartidor en la base de datos
            Bodeguero b = em.find(Bodeguero.class, cdl);

            if (b != null) {
                LocalDate f = LocalDate.now();
                // Buscamos al cliente
                System.out.println("Ingrese el número de cédula del cliente\n"
                        + "al cual desea cambiarle el estado del paquete");
                String cdlCl = sc.next();
                sc.nextLine(); // Limpiar el buffer de entrada

                Cliente c = em.find(Cliente.class, cdlCl);

                if (c != null) {
                    if (c.getPaquetes().size() > 1) {
                        for (Paquete p : c.getPaquetes()) {
                            System.out.println(p + "\n");
                        }
                        System.out.println("¿De qué paquete quiere editar el estado?");
                        int idP = sc.nextInt();
                        sc.nextLine(); // Limpiar el buffer de entrada

                        // Ahora buscamos al paquete
                        Paquete p = em.find(Paquete.class, idP);
                        Estado e;
                        // Se valida que el paquete exista
                        if (p != null) {
                            // Editamos el estado
                            System.out.println("Encontramos el paquete");
                            System.out.println("¿Qué estado desea modificar?");
                            System.out.println("Recuerde que la fecha no se puede editar");
                            System.out.println("[1] Creado");
                            System.out.println("[2] Despachado");
                            System.out.println("[3] Pendiente");
                            System.out.println("[4] Entregado");
                            int op = sc.nextInt();
                            sc.nextLine(); // Limpiar el buffer de entrada

                            switch (op) {
                                case 1:
                                    e = em.find(Estado.class, p.getEstados()[0].getTipo());
                                    if (e != null) {
                                        controller.actualizarEstado(actualizarSoloObs(e));
                                    } else {
                                        System.err.println("Este paquete ni siquiera se ha creado");
                                        System.out.println("Crea el paquete para poder editar este estado");
                                    }
                                    break;
                                case 2:
                                    e = em.find(Estado.class, p.getEstados()[1].getTipo());
                                    if (e != null) {
                                        controller.actualizarEstado(actualizarSoloObs(e));
                                    } else {
                                        controller.crearEstado(crearEstadoPaquete(p, 1));
                                    }
                                    break;
                                case 3:
                                    e = em.find(Estado.class, p.getEstados()[2].getTipo());
                                    if (e != null) {
                                        controller.actualizarEstado(actualizarSoloObs(e));
                                    } else {
                                        controller.crearEstado(crearEstadoPaquete(p, 2));
                                    }
                                    break;
                                case 4:
                                    e = em.find(Estado.class, p.getEstados()[3].getTipo());
                                    if (e != null) {
                                        controller.actualizarEstado(actualizarSoloObs(e));
                                    } else {
                                        controller.crearEstado(crearEstadoPaquete(p, 3));
                                    }
                                    break;
                                default:
                                    System.err.println("Número inválido");
                                    break;
                            }
                        } else {
                            System.err.println("Error");
                            System.err.println("Ingresó mal el ID del paquete");
                        }

                        // Si se tiene solo un paquete entonces se trabaja sobre este
                    } else if (c.getPaquetes().size() == 1) {
                        Paquete p = em.find(Paquete.class, c.getPaquetes().get(0).getIdPaquete());
                        System.out.println("¡Enhorabuena!");
                        System.out.println("Este cliente solo ha tenido un paquete :D");
                        System.out.println("No va a haber mucho papeleo :D");

                        // Si no tiene ningún paquete entonces se muestra mensaje de error
                    } else {
                        System.err.println("ATENCIÓN:");
                        System.out.println("Este cliente no ha tenido ningún paquete registrado");
                    }
                } else {
                    System.err.println("Cliente no encontrado");
                }

                em.getTransaction().commit();
            } else {
                System.err.println("Bodeguero no encontrado :(");
            }

            // Finaliza la transacción
            em.getTransaction().commit();
        } catch (Exception e) {
            // Si ocurre un error, revertir la transacción
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            // Asegurarse de cerrar el EntityManager
            if (em.isOpen()) {
                em.close();
            }
        }
    }

    public static Estado crearEstado(String name, LocalDate f) {
        System.out.println("Observación: ");
        String obs = sc.next();

        return new Estado(0, name, f, obs);
    }
}

/*
try (EntityManagerFactory entityManagerFactory =
                     Persistence.createEntityManagerFactory("persistenciaUWU")) {
            // EntityManager -> Persistence Context //
EntityManager em = entityManagerFactory.createEntityManager(); // Representa el conexto de persistencia, se utiliza para manejar las transacciones

            em.getTransaction().begin();

                    Cliente c = new Cliente("1104692163","Verónica","Luna","vs@utpl.ec", "+593 991317177");
                    em.persist(c);

                    System.out.println(c);

                    em.getTransaction().commit();
                    }
* */
