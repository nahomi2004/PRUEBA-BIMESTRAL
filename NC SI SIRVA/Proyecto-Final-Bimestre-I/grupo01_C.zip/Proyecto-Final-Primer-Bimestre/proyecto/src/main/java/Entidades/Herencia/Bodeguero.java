package Entidades.Herencia;

import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import Entidades.NoHerencia.Paquete;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Bodeguero extends  Empleado {
    private String local;

    @OneToMany(mappedBy = "bodeguero")
    private List<Paquete> paquetes;

    public Bodeguero() {
    }

    public Bodeguero(String cedula, String nombre, String apellido, String mail, String ciudad, String local) {
        super(cedula, nombre, apellido, mail, ciudad);
        this.local = local;
        this.paquetes = new ArrayList<>();
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public List<Paquete> getPaquetes() {
        return paquetes;
    }

    public void setPaquetes(List<Paquete> paquetes) {
        this.paquetes = paquetes;
    }

    @Override
    public String toString() {
        return super.toString() + "\n\tTipo: Bodeguero" +
                "\n\tLocal: " + local;
    }
}
