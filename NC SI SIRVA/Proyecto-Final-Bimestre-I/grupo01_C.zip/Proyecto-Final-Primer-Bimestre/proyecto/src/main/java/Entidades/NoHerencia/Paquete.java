package Entidades.NoHerencia;

import Entidades.Herencia.*;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.Arrays;

@Entity
public class Paquete {
    @Id
    private int idPaquete;

    @Basic
    private String codigo;
    private String descrip;
    private double peso;
    private double alto;

    @ManyToOne
    @JoinColumn(name = "cliente_cedula")
    private Cliente cliente;

    @OneToMany(mappedBy = "paquete")
    private Estado[] estados;

    @ManyToOne
    @JoinColumn(name = "entrega_codigo")
    private Entrega entrega;

    @ManyToOne
    @JoinColumn(name = "bodeguero_cedula")
    private Bodeguero bodeguero;
    public Paquete() {
    }

    public Paquete(int idPaquete, String codigo, String descrip, double peso, double alto) {
        this.idPaquete = idPaquete;
        this.codigo = codigo;
        this.descrip = descrip;
        this.peso = peso;
        this.alto = alto;
        this.estados = new Estado[4];
        // estados[0] = new Estado(1, "Creado", LocalDate.now(), "Creado con éxito");
    }

    public int getIdPaquete() {
        return idPaquete;
    }

    public void setIdPaquete(int idPaquete) {
        this.idPaquete = idPaquete;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescrip() {
        return descrip;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAlto() {
        return alto;
    }

    public void setAlto(double alto) {
        this.alto = alto;
    }

    public Estado[] getEstados() {
        return estados;
    }

    public void setEstados(Estado[] estados) {
        this.estados = estados;
    }

    public Entrega getEntrega() {
        return entrega;
    }

    public void setEntrega(Entrega entrega) {
        this.entrega = entrega;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Bodeguero getBodeguero() {
        return bodeguero;
    }

    public void setBodeguero(Bodeguero bodeguero) {
        this.bodeguero = bodeguero;
    }

    @Override
    public String toString() {
        String cadena = String.format("Paquete" +
                "\n\tID: " + idPaquete +
                "\n\tCodigo: " + codigo +
                "\n\tDescripción: " + descrip +
                "\n\tPeso: " + peso +
                "\n\tAlto: " + alto +
                "\n\tEstados: ");

        for(int i = 0; i < 4; i++) {
            if (estados[i] == null) {
                break;
            }
            cadena = cadena + estados[i].toString() + "\n";
        }

        return cadena;
    }
}
