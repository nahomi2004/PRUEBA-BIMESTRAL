package Logica;

import Entidades.Herencia.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LPersona {
    private Persona persona;

    public LPersona() {
    }

    public LPersona(Cliente cliente) {
        this.persona = cliente;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Cliente persona) {
        this.persona = persona;
    }

    public Boolean comprobarCedula(String cedula) {
        return cedula.length() == 10 && cedula.substring(0, 9).matches("[0-9]*");
    }

    public Boolean comprobarCorreo(String email) {
        String regex = "^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
