/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BDProyecto;

import BDProyecto.exceptions.NonexistentEntityException;
import BDProyecto.exceptions.PreexistingEntityException;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import Entidades.NoHerencia.*;
import Entidades.Herencia.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.List;

/**
 *
 * @author User
 */
public class PaqueteJpaController implements Serializable {

    public PaqueteJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    public PaqueteJpaController() {
        emf = Persistence.createEntityManagerFactory("persistenciaUWU");
    }

    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Paquete paquete) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cliente cliente = paquete.getCliente();
            if (cliente != null) {
                cliente = em.getReference(cliente.getClass(), cliente.getCedula());
                paquete.setCliente(cliente);
            }
            Entrega entrega = paquete.getEntrega();
            if (entrega != null) {
                entrega = em.getReference(entrega.getClass(), entrega.getCodigo());
                paquete.setEntrega(entrega);
            }
            Bodeguero bodeguero = paquete.getBodeguero();
            if (bodeguero != null) {
                bodeguero = em.getReference(bodeguero.getClass(), bodeguero.getCedula());
                paquete.setBodeguero(bodeguero);
            }
            Estado[] estados = paquete.getEstados();
            if (estados != null) {
                for (int i = 0; i < estados.length; i++) {
                    if (estados[i] != null) {
                        estados[i] = em.getReference(estados[i].getClass(), estados[i].getTipo());
                        estados[i].setPaquete(paquete);
                    }
                }
            }
            em.persist(paquete);
            if (cliente != null) {
                cliente.getPaquetes().add(paquete);
                cliente = em.merge(cliente);
            }
            if (entrega != null) {
                entrega.getPaquetes().add(paquete);
                entrega = em.merge(entrega);
            }
            if (bodeguero != null) {
                bodeguero.getPaquetes().add(paquete);
                bodeguero = em.merge(bodeguero);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findPaquete(paquete.getIdPaquete()) != null) {
                throw new PreexistingEntityException("Paquete " + paquete + " ya existe.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Paquete paquete) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Paquete persistentPaquete = em.find(Paquete.class, paquete.getIdPaquete());
            Cliente clienteOld = persistentPaquete.getCliente();
            Cliente clienteNew = paquete.getCliente();
            Entrega entregaOld = persistentPaquete.getEntrega();
            Entrega entregaNew = paquete.getEntrega();
            Bodeguero bodegueroOld = persistentPaquete.getBodeguero();
            Bodeguero bodegueroNew = paquete.getBodeguero();
            Estado[] estadosOld = persistentPaquete.getEstados();
            Estado[] estadosNew = paquete.getEstados();

            if (clienteNew != null) {
                clienteNew = em.getReference(clienteNew.getClass(), clienteNew.getCedula());
                paquete.setCliente(clienteNew);
            }
            if (entregaNew != null) {
                entregaNew = em.getReference(entregaNew.getClass(), entregaNew.getCodigo());
                paquete.setEntrega(entregaNew);
            }
            if (bodegueroNew != null) {
                bodegueroNew = em.getReference(bodegueroNew.getClass(), bodegueroNew.getCedula());
                paquete.setBodeguero(bodegueroNew);
            }
            if (estadosNew != null) {
                for (int i = 0; i < estadosNew.length; i++) {
                    if (estadosNew[i] != null) {
                        estadosNew[i] = em.getReference(estadosNew[i].getClass(), estadosNew[i].getTipo());
                        estadosNew[i].setPaquete(paquete);
                    }
                }
            }
            paquete = em.merge(paquete);
            if (clienteOld != null && !clienteOld.equals(clienteNew)) {
                clienteOld.getPaquetes().remove(paquete);
                clienteOld = em.merge(clienteOld);
            }
            if (clienteNew != null && !clienteNew.equals(clienteOld)) {
                clienteNew.getPaquetes().add(paquete);
                clienteNew = em.merge(clienteNew);
            }
            if (entregaOld != null && !entregaOld.equals(entregaNew)) {
                entregaOld.getPaquetes().remove(paquete);
                entregaOld = em.merge(entregaOld);
            }
            if (entregaNew != null && !entregaNew.equals(entregaOld)) {
                entregaNew.getPaquetes().add(paquete);
                entregaNew = em.merge(entregaNew);
            }
            if (bodegueroOld != null && !bodegueroOld.equals(bodegueroNew)) {
                bodegueroOld.getPaquetes().remove(paquete);
                bodegueroOld = em.merge(bodegueroOld);
            }
            if (bodegueroNew != null && !bodegueroNew.equals(bodegueroOld)) {
                bodegueroNew.getPaquetes().add(paquete);
                bodegueroNew = em.merge(bodegueroNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                int id = paquete.getIdPaquete();
                if (findPaquete(id) == null) {
                    throw new NonexistentEntityException("The paquete with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(int id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Paquete paquete;
            try {
                paquete = em.getReference(Paquete.class, id);
                paquete.getIdPaquete();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The paquete with id " + id + " no longer exists.", enfe);
            }
            Cliente cliente = paquete.getCliente();
            if (cliente != null) {
                cliente.getPaquetes().remove(paquete);
                cliente = em.merge(cliente);
            }
            Entrega entrega = paquete.getEntrega();
            if (entrega != null) {
                entrega.getPaquetes().remove(paquete);
                entrega = em.merge(entrega);
            }
            Bodeguero bodeguero = paquete.getBodeguero();
            if (bodeguero != null) {
                bodeguero.getPaquetes().remove(paquete);
                bodeguero = em.merge(bodeguero);
            }
            Estado[] estados = paquete.getEstados();
            if (estados != null) {
                for (Estado estado : estados) {
                    if (estado != null) {
                        estado.setPaquete(null);
                        em.merge(estado);
                    }
                }
            }
            em.remove(paquete);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Paquete> findPaqueteEntities() {
        return findPaqueteEntities(true, -1, -1);
    }

    public List<Paquete> findPaqueteEntities(int maxResults, int firstResult) {
        return findPaqueteEntities(false, maxResults, firstResult);
    }

    private List<Paquete> findPaqueteEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Paquete.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Paquete findPaquete(int id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Paquete.class, id);
        } finally {
            em.close();
        }
    }

    public int getPaqueteCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Paquete> rt = cq.from(Paquete.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
}